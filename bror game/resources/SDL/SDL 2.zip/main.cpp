#include <iostream>

#include <SDL.h>
#include <SDL_image.h>

using namespace std;

SDL_Window *window;
SDL_Renderer *renderer;

bool init()
{
	if(SDL_Init(SDL_INIT_EVERYTHING) < 0)
	{
		std::cout << "SDL initialization failed. SDL Error: " << SDL_GetError() << std::endl;
		return false;
	}
	else
	{
		std::cout << "SDL initialization succeeded!" << std::endl;

		if(IMG_Init(IMG_INIT_PNG) == 0)
		{
			std::cout << "SDL image initialization failed. SDL Error: " << IMG_GetError() << std::endl;
			return false;
		}
		else
		{
			std::cout << "SDL image initialization succeeded!" << std::endl;
			return true;
		}
	}


}



int main(int argc, char * argv[])
{
	if(init())
	{
		window = SDL_CreateWindow("window", 0, 0, 100, 100, SDL_WINDOW_OPENGL);
		renderer = SDL_CreateRenderer(window, 0, 0);
	}

	cin.get();
	return 0;
}